#ifndef FPKG_BACKEND_H
#define FPKG_BACKEND_H
#include <stddef.h>
/* Backend contract: implement using verified 13.60 install/launch facilities.
 * Return zero on success; nonzero otherwise. Never silently report success. */
int backend_ready(char *reason, size_t reason_size);
int backend_install(const char *absolute_pkg_path);
int backend_launch(const char *title_id);
int backend_list(void);
#endif
