#include "backend.h"
#include <stdio.h>
#include <string.h>
int backend_ready(char *reason, size_t size) {
  const char *msg="No verified PS5 13.60 FPKG/HEN backend has been connected";
  if (size) snprintf(reason, size, "%s", msg);
  return 0;
}
int backend_install(const char *path) {
  (void)path;
  fprintf(stderr, "Install unavailable: a verified 13.60 FPKG installer backend is required.\n");
  return -1;
}
int backend_launch(const char *id) {
  (void)id;
  fprintf(stderr, "Launch unavailable: a verified 13.60 unsigned execution backend is required.\n");
  return -1;
}
int backend_list(void) {
  fprintf(stderr, "List unavailable: installed application enumeration backend required.\n");
  return -1;
}
