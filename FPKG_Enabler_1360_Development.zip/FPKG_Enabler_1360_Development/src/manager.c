/* PS5 FPKG Manager 13.60 proof-of-concept (payload, not an installable app).
 * This program DOES NOT bypass signature/licensing checks.
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <ps5/kernel.h>
#include "backend.h"

#define FW_1360 0x13600000u
#define PKG_MAGIC 0x7f434e54u /* standard Sony PKG header magic (big endian) */

static uint32_t be32(const unsigned char *b) {
  return ((uint32_t)b[0]<<24)|((uint32_t)b[1]<<16)|((uint32_t)b[2]<<8)|b[3];
}
static int firmware_check(void) {
  uint32_t fw=kernel_get_fw_version();
  if ((fw & 0xffff0000u) != FW_1360) {
    fprintf(stderr,"Unsupported firmware: %02x.%02x (only 13.60 accepted)\n",
           (unsigned)(fw>>24), (unsigned)((fw>>16)&0xff));
    return -1;
  }
  printf("Firmware verified: 13.60\n");
  return 0;
}
static int inspect_pkg(const char *path) {
  unsigned char header[32];
  FILE *f=fopen(path,"rb");
  if (!f) {perror("open PKG");return 1;}
  size_t got=fread(header,1,sizeof(header),f);
  fclose(f);
  if (got < 4) {fprintf(stderr,"Invalid package: insufficient header data\n");return 1;}
  if (be32(header)!=PKG_MAGIC) {
    fprintf(stderr,"File does not have the expected PKG magic (7F 43 4E 54)\n");
    return 1;
  }
  printf("PKG header magic is present: %s\n",path);
  printf("NOTE: This does not prove FPKG authenticity, installability or safety.\n");
  return 0;
}
static void usage(const char *p) {
  printf("Usage:\n  %s status\n  %s inspect /absolute/path/file.pkg\n"
         "  %s install /absolute/path/file.pkg\n  %s launch TITLEID\n  %s list\n", p,p,p,p,p);
}
int main(int argc,char **argv) {
  char reason[192];
  if (firmware_check()) return 2;
  if (argc<2) {usage(argv[0]);return 1;}
  if (!strcmp(argv[1],"status")) {
    if (backend_ready(reason,sizeof(reason))) {puts("Backend ready");return 0;}
    printf("HV status: not independently verified by this app.\nBackend: %s\n",reason);
    return 3;
  }
  if (!strcmp(argv[1],"inspect") && argc==3) return inspect_pkg(argv[2]);
  if (!strcmp(argv[1],"install") && argc==3) {
    if (inspect_pkg(argv[2])) return 1;
    if (!backend_ready(reason,sizeof(reason))) {fprintf(stderr,"%s\n",reason);return 3;}
    return backend_install(argv[2]);
  }
  if (!strcmp(argv[1],"launch") && argc==3) {
    if (!backend_ready(reason,sizeof(reason))) {fprintf(stderr,"%s\n",reason);return 3;}
    return backend_launch(argv[2]);
  }
  if (!strcmp(argv[1],"list") && argc==2) {
    if (!backend_ready(reason,sizeof(reason))) {fprintf(stderr,"%s\n",reason);return 3;}
    return backend_list();
  }
  usage(argv[0]); return 1;
}
