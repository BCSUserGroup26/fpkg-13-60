#!/usr/bin/env python3
"""Offline, read-only inspection of ELF/PKG inputs; no PS5 modifications."""
import argparse
from pathlib import Path
import struct

def inspect(path):
    p = Path(path)
    try:
        with p.open('rb') as f:
            head = f.read(64)
    except OSError as e:
        print(f'{p}: ERROR {e}')
        return False
    if head[:4] == b'\x7fELF':
        if len(head) < 20:
            print(f'{p}: invalid/truncated ELF'); return False
        bitness = {1:'32-bit',2:'64-bit'}.get(head[4], 'unknown class')
        endian = {1:'little',2:'big'}.get(head[5],'unknown')
        if endian not in ('little','big'):
            print(f'{p}: invalid ELF endianness'); return False
        etype, machine = struct.unpack(('<' if endian=='little' else '>')+'HH',head[16:20])
        print(f'{p}: ELF {bitness}, {endian}-endian, e_type={etype}, e_machine={machine}, size={p.stat().st_size}')
        print('  ELF header alone does not verify firmware compatibility or payload safety.')
        return True
    if head[:4] == b'\x7fCNT':
        print(f'{p}: Sony PKG magic found; size={p.stat().st_size}')
        print('  Header alone does not prove fake-signing, installability or compatibility.')
        return True
    print(f'{p}: unrecognized ELF/PKG magic')
    return False

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='+')
    args=parser.parse_args()
    raise SystemExit(0 if all([inspect(p) for p in args.files]) else 1)
