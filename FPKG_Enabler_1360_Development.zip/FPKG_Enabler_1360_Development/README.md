# FPKG Enabler 13.60 — Development Package

**STATUS: NOT A FUNCTIONAL FPKG ENABLER. Do not treat this package as ready to run PS5 FPKGs.**

Target firmware: **PS5 13.60 only.**

## What is included

- `src/manager.c`: firmware 13.60 gate, PKG magic inspection, CLI dispatch.
- `src/backend.h`: integration interface for a verified 13.60 HEN runtime.
- `src/backend_unavailable.c`: explicit safe failure until real support is available.
- `reference/byepervisor_13_60.h`: copied unchanged from your uploaded Byepervisor Reborn source ZIP for research/reference only.
- `tools/check_inputs.py`: safe, offline source/binary/PKG checks on a PC.
- `Makefile`: payload build target requiring the PS5-Payload-Dev SDK.

The package deliberately **does not** include a guessed kernel patchset, offsets for undocumented fPKG checks, nor code purporting to disable licenses. `install`, `launch` and `list` currently refuse to operate. `status` does not establish that a hypervisor exploit is active.

## What your uploads establish

1. Byepervisor Reborn has an explicit 13.60 offsets header and a rest-mode hypervisor exploit sequence.
2. At the end of the resumed exploit path, `main.c` contains a `TODO` to patch the kernel; it does not ship a HEN patchset.
3. Your 1360 Linux ELF plus reported successful Fedora 44 boot demonstrate Linux boot in your particular environment, not PS5 fPKG compatibility.
4. The S3 resume write-up describes write/readback/restore testing of all sixteen VMCBs, but not PS5 fPKG checks.

## Intended workflow after a verified FPKG backend exists

1. Run Byepervisor Reborn on FW 13.60 using its documented loader.
2. Enter rest mode and resume.
3. Load a compatible, independently verified PS5 GameOS 13.60 unsigned-code/FPKG execution backend.
4. Invoke the manager to install or launch a package you are authorized to use.

At present, step 3 is not supplied by this project. etaHEN being present does not prove PS5 FPKG support is active.

## Build (SDK environment only)

```
export PS5_PAYLOAD_SDK=/path/to/ps5-payload-sdk
make
```

**No compiled console ELF is included:** the SDK and hardware validation are not available here. The example command-line argument path may not work with every payload loader.

## References

- https://github.com/PS5Dev/Byepervisor-Reborn
- https://github.com/EchoStretch/kstuff-lite
- https://github.com/Michele-M-Media/HYPERHEN

This project has not been run on a PS5. Do not modify the user's proven working exploit binary.
